package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import java.io.IOException;

import org.example.model.BankAccount;
import org.example.util.SceneManager;

public class BalanceController {

    @FXML
    private Label balanceLabel;

    @FXML
    public void initialize() {
        double currentBalance = BankAccount.getBalance(); // 💰 Get real balance
        balanceLabel.setText("現在の残高: ¥" + String.format("%,.0f", currentBalance));
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        SceneManager.switchScene((Node) event.getSource(), "/view/MainMenu.fxml");
    }
}
