package org.example.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import java.io.IOException;
import org.example.util.SceneManager;

public class MainMenuController {

    @FXML
    private void handleBalance(ActionEvent event) throws IOException {
        SceneManager.switchScene((Node) event.getSource(), "/view/Balance.fxml");
    }

    @FXML
    private void handleDeposit(ActionEvent event) throws IOException {
        SceneManager.switchScene((Node) event.getSource(), "/view/Deposit.fxml");
    }

    @FXML
    private void handleWithdraw(ActionEvent event) throws IOException {
        SceneManager.switchScene((Node) event.getSource(), "/view/Withdraw.fxml");
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        SceneManager.switchScene((Node) event.getSource(), "/view/LoginView.fxml");
    }
}
