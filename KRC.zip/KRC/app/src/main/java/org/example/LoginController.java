package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import java.io.IOException;

import org.example.util.SceneManager;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private void handleLogin(ActionEvent event) {
        
        String username = usernameField.getText();
        String password = passwordField.getText();

        if ("shreeram".equals(username) && "1234".equals(password)) {
            try {
                System.out.println("Trying to load MainMenu.fxml...");
                SceneManager.switchScene((Node) event.getSource(), "/view/MainMenu.fxml");
                System.out.println("MainMenu.fxml loaded successfully!");
            } 

 catch (Exception e) {
    e.printStackTrace();
    showAlert("エラー", "メインメニューの読み込みに失敗しました。");
}


        } else {
            showAlert("エラー", "ユーザー名またはパスワードが間違っています。");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
