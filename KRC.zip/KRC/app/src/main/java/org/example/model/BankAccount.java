package org.example.model;

import java.io.*;

public class BankAccount {
    private static final String FILE_PATH = "balance.txt";
    private static double balance = 0;

    static {
        loadBalance();
    }

    public static double getBalance() {
        return balance;
    }

    public static void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            saveBalance();
        }
    }

    public static boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            saveBalance();
            return true;
        }
        return false;
    }

    private static void loadBalance() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line = reader.readLine();
            if (line != null) {
                balance = Double.parseDouble(line);
            }
        } catch (IOException | NumberFormatException e) {
            balance = 50000.0; // Default starting balance
            saveBalance();     // Save it for next time
        }
    }

    private static void saveBalance() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            writer.write(String.valueOf(balance));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
