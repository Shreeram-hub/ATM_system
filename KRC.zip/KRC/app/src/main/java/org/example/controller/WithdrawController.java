package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import java.io.IOException;

import org.example.model.BankAccount;
import org.example.util.SceneManager;

public class WithdrawController {

    @FXML
    private TextField amountField;

    @FXML
    private void handleWithdraw(ActionEvent event) {
        try {
            double amount = Double.parseDouble(amountField.getText());
            if (amount > 0) {
                boolean success = BankAccount.withdraw(amount); // 💸 Try to withdraw
                if (success) {
                    showAlert("成功", "¥" + (int)amount + " を出金しました。\n新しい残高: ¥" + (int)BankAccount.getBalance());
                    amountField.clear();
                } else {
                    showAlert("エラー", "残高不足、または無効な金額です。");
                }
            } else {
                showAlert("エラー", "正しい金額を入力してください。");
            }
        } catch (NumberFormatException e) {
            showAlert("エラー", "数値を入力してください。");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        SceneManager.switchScene((Node) event.getSource(), "/view/MainMenu.fxml");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
