package org.example.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.io.IOException;

public class SceneManager {

    private static final String STYLESHEET_PATH = "/style/style.css";

    public static void switchScene(Node source, String fxmlPath) throws IOException {
        FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource(fxmlPath));
        Scene scene = new Scene(loader.load(), 640, 540);
        scene.getStylesheets().add(SceneManager.class.getResource(STYLESHEET_PATH).toExternalForm());

        Stage stage = (Stage) source.getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
    }
}
